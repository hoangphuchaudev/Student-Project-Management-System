  <link href="{{asset('public/FE/vendor/fontawesome-free/css/all.min.css')}}" rel="stylesheet" type="text/css">
  <link href="https://fonts.googleapis.com/css?family=Nunito:200,200i,300,300i,400,400i,600,600i,700,700i,800,800i,900,900i" rel="stylesheet">
  
  <link rel="stylesheet" type="text/css" href="{{asset('public/FE/css/csslichbaocao.css')}}">

  <!-- Custom styles for this template-->
  <link href="{{asset('public/FE/css/An.css')}}" rel="stylesheet">



 <script src="{{URL::asset('public/FE/vendor/jquery/jquery.min.js')}}"></script>
  <script src="{{URL::asset('public/FE/vendor/bootstrap/js/bootstrap.bundle.min.js')}}"></script>

  <!-- Core plugin JavaScript-->
  <script src="{{URL::asset('public/FE/vendor/jquery-easing/jquery.easing.min.js')}}"></script>

  <!-- Custom scripts for all pages-->
  <script src="{{URL::asset('public/FE/js/sb-admin-2.min.js')}}"></script>

  <!-- Page level plugins -->
  <script src="{{URL::asset('public/FE/vendor/chart.js/Chart.min.js')}}"></script>

  <!-- Page level custom scripts -->
  <script src="{{URL::asset('public/FE/js/demo/chart-area-demo.js')}}"></script>
  <script src="{{URL::asset('public/FE/js/demo/chart-pie-demo.js')}}"></script>

  <!--   Link ckeditor -->
  <script type="text/javascript" src="{{URL::asset('public/FE/ckeditor/ckeditor.js')}}"></script>