@include('sinhvien/includes/adminleft')
@include('sinhvien/includes/topcontent')
   
  @yield('content')
  
    <div style="height: 200px;">
    </div>
@include('sinhvien/includes/footer')