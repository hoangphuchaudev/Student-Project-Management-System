@include('sinhvien/includes/adminleft')
@include('sinhvien/includes/topcontent')
<h1>Trang kế hoạch thực hiện</h1>
@include('sinhvien/includes/footer')