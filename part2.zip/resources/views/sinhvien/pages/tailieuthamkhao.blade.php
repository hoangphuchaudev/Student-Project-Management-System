@include('sinhvien/includes/adminleft')
@include('sinhvien/includes/topcontent')
<h1>Trang tài liệu tham khảo</h1>
@include('sinhvien/includes/footer')