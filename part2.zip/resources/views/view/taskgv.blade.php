
          <div class="row">

            <!-- Earnings (Monthly) Card Example -->

            <div class="col-xl-3 col-md-6 mb-4">
              <a href="{{URL::to('quanlydetai/'.$MaDA)}}" style="text-decoration: none;">
              <div class="card border-left-primary shadow h-100 py-2">
                <div class="card-body">
                  <div class="row no-gutters align-items-center">
                    <div class="col mr-2">
                      <div class="h5 mb-0 font-weight-bold text-primary  mb-1">Quản lý đề tài</div>
                      <img src="{{ asset('public/FE/img/adddetai.png') }}" alt="placeholder+image">
                    </div>
                    <div class="col-auto">
                      <!-- <i class="fas fa-calendar fa-2x text-gray-300"></i> -->
                    </div>
                  </div>
                </div>
              </div>
              </a>
            </div>

            <!-- Earnings (Monthly) Card Example -->
            <div class="col-xl-3 col-md-6 mb-4">
              <a href="{{URL::to('quanlylichbaocao/'.$MaDA)}}" style="text-decoration: none;">
              <div class="card border-left-danger shadow h-100 py-2">
                <div class="card-body">
                  <div class="row no-gutters align-items-center">
                    <div class="col mr-2">
                       <div class="h5 mb-0 font-weight-bold text-danger mb-1">Xếp lịch báo cáo</div>
                      <img src="{{ asset('public/FE/img/xeplichbaocao.png') }}" alt="placeholder+image">
                    </div>
                    <div class="col-auto">
                     <!--  <i class="fas fa-dollar-sign fa-2x text-gray-300"></i> -->
                    </div>
                  </div>
                </div>
              </div>
            </a>
            </div>

            <!-- Earnings (Monthly) Card Example -->
            <div class="col-xl-3 col-md-6 mb-4">
               <a href="{{URL::to('quanlykehoach/'.$MaDA)}}" style="text-decoration: none;">
              <div class="card border-left-success shadow h-100 py-2">
                <div class="card-body">
                  <div class="row no-gutters align-items-center">
                    <div class="col mr-2">
                   <div class="h5 mb-0 font-weight-bold text-success mb-1">Kế hoạch thực hiện</div>
                      <img src="{{  asset('public/FE/img/tiendo.png') }}" alt="placeholder+image">
                      </div>
                    </div>
                    <div class="col-auto">
                     <!--  <i class="fas fa-clipboard-list fa-2x text-gray-300"></i> -->
                    </div>
                  </div>
                </div>
              </a>
              </div>

             
              <div class="col-xl-3 col-md-6 mb-4">
                <a href="{{URL::to('quanlysinhvien/'.$MaDA)}}" style="text-decoration: none;">
              <div class="card border-left-warning shadow h-100 py-2">
                <div class="card-body">
                  <div class="row no-gutters align-items-center">
                    <div class="col mr-2">
                       <div class="h5 mb-0 font-weight-bold text-warning mb-1">Xem thông tin sinh viên</div>
                      <img src="{{  asset('public/FE/img/infosv.png') }}" alt="placeholder+image">
                    </div>
                    <div class="col-auto">
                     <!--  <i class="fas fa-comments fa-2x text-gray-300"></i> -->
                    </div>
                  </div>
                </div>
              </div>
              </a>
            </div>
          
            </div>

            <!-- Pending Requests Card Example -->
            
          </div>
          <br><br><br>
          <br><br><br>
          <br><br><br>
          <br><br><br>
           <br><br><br>
            <br><br><br>
